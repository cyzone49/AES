# CS465_Security
# README for AES

Dat Vu

How to compile aes.py: From terminal: run python3 aes.py
- The main() method (line 363) contains all of the test cases in Appendix C of the FIPS specification
- First test case AES 128 ( nk = 4, nr = 10 ) is configured with debugMode on. The other two are not
- To enable debugMode in each test case, add True to the parameters of testCipher() and testInvCipher().


